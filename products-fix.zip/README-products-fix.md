# Products fix — how to deploy

## What changed
- **New file: `products-store.js`** — saves every product as its own document in a new `products` MongoDB collection, instead of all products being crammed into one array inside your single `app_data` document.
- **Updated: `database.js`** — uses `products-store.js` to load/save products, and auto-migrates your existing embedded products the first time it starts up after deploy. No manual script needs to be run.
- **`server.js` — no changes needed.** It only ever reads/writes `database.products` as a plain array and calls `writeDatabase()`, so all ~50 of your existing product routes (admin add/edit/delete, seller uploads, storefront, cart, orders, etc.) keep working exactly as before.

## Why this fixes it
Your `app_data` document (with all product photos embedded) had grown to 35.5MB — way past MongoDB's 16MB single-document limit — which is why saves/uploads were failing. Products now live as individual documents, so the limit applies per product, not to your whole catalog.

## Deploy steps
1. In your GitHub repo (`omgomx-cell/designmakers-website`), replace `database.js` with the one here, and add `products-store.js` as a new file in the same folder.
2. Commit and push to `main` — AIC Cloud will redeploy automatically.
3. Watch the deploy logs. On first boot you should see:
   ```
   Design Makers database loaded from MongoDB.
   One-time migration: moved N product(s) out of app_data into their own 'products' collection.
   Loaded N product(s) from the 'products' collection.
   ```
   That migration line only appears once — on every later restart it'll just say "Loaded N product(s)..." with no migration line, since there's nothing left to migrate.
4. Test: add a product from the admin panel, refresh, confirm it's still there. Try uploading a few product photos to be sure large images save fine now.

## Note
`migrate-products.js` (the standalone script you had) is no longer needed — the migration now happens automatically inside `database.js` itself on deploy. You can delete it from the repo if you like, or keep it as a manual backup tool.
